﻿namespace DTO

{
    public class CourseDTO
    {
        public float score { get; set; }
        public string courseName { get; set; }
        public float credit { get; set; }
    }
}
