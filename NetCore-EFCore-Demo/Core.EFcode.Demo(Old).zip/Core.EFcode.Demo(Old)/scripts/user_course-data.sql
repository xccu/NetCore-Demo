INSERT INTO `user_course` (`USER_ID`, `COURSE_ID`, `score`) VALUES(1,1,90);
INSERT INTO `user_course` (`USER_ID`, `COURSE_ID`, `score`) VALUES(1,2,80);
INSERT INTO `user_course` (`USER_ID`, `COURSE_ID`, `score`) VALUES(1,3,85);

INSERT INTO `user_course` (`USER_ID`, `COURSE_ID`, `score`) VALUES(2,1,80);
INSERT INTO `user_course` (`USER_ID`, `COURSE_ID`, `score`) VALUES(2,2,85);
INSERT INTO `user_course` (`USER_ID`, `COURSE_ID`, `score`) VALUES(2,4,75);

INSERT INTO `user_course` (`USER_ID`, `COURSE_ID`, `score`) VALUES(3,2,70);
INSERT INTO `user_course` (`USER_ID`, `COURSE_ID`, `score`) VALUES(3,3,75);
INSERT INTO `user_course` (`USER_ID`, `COURSE_ID`, `score`) VALUES(3,4,90);