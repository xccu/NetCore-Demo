INSERT INTO `course` (`COURSE_ID`,`COURSE_NAME`, `credit`) VALUES(1,'math',4.0);
INSERT INTO `course` (`COURSE_ID`,`COURSE_NAME`, `credit`) VALUES(2,'c#',3.0);
INSERT INTO `course` (`COURSE_ID`,`COURSE_NAME`, `credit`) VALUES(3,'java',3.0);
INSERT INTO `course` (`COURSE_ID`,`COURSE_NAME`, `credit`) VALUES(4,'sql',2.0);