insert into `user` (`USER_ID`, `USER_NAME`, `PASSWORD`, `Age`, `Sex`, `Race`) values('1','Weslie','123','12','male','Caprinae');
insert into `user` (`USER_ID`, `USER_NAME`, `PASSWORD`, `Age`, `Sex`, `Race`) values('2','Wolffy','456','34','male','Lupo');
insert into `user` (`USER_ID`, `USER_NAME`, `PASSWORD`, `Age`, `Sex`, `Race`) values('3','Paddi','123','11','male','Caprinae');
insert into `user` (`USER_ID`, `USER_NAME`, `PASSWORD`, `Age`, `Sex`, `Race`) values('4','Sparky','123','12','male','Caprinae');
insert into `user` (`USER_ID`, `USER_NAME`, `PASSWORD`, `Age`, `Sex`, `Race`) values('5','Tibby','123','11','female','Caprinae');
insert into `user` (`USER_ID`, `USER_NAME`, `PASSWORD`, `Age`, `Sex`, `Race`) values('6','Wilie','456','5','male','Lupo');
insert into `user` (`USER_ID`, `USER_NAME`, `PASSWORD`, `Age`, `Sex`, `Race`) values('7','AngelaLily','456','4','female','Lupo');
insert into `user` (`USER_ID`, `USER_NAME`, `PASSWORD`, `Age`, `Sex`, `Race`) values('8','Wolnie','456','33','female','Lupo');