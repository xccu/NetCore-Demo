﻿namespace Models
{
    public class User { 
        string name; 
        string render; 
        int age; 
        string race; }
}