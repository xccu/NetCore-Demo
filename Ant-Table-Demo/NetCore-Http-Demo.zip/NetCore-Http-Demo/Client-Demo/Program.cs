using Client_Demo.Models;
using Client_Demo.Services;
using Microsoft.Net.Http.Headers;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Add services to the container.
builder.Services.AddHttpClient();
//builder.Services.AddHttpClient("testClient", (HttpClient c) => { c.BaseAddress = new Uri("http://localhost:5041"); });

builder.Services.AddHttpClient("testClient", httpClient =>
{
    httpClient.BaseAddress = new Uri("https://localhost:7168/");

    // using Microsoft.Net.Http.Headers;
    // The GitHub API requires two headers.
    httpClient.DefaultRequestHeaders.Add(
        HeaderNames.Accept, "application/vnd.github.v3+json");
    httpClient.DefaultRequestHeaders.Add(
        HeaderNames.UserAgent, "HttpRequestsSample");
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

var httpClient = app.Services.GetRequiredService<IHttpClientFactory>().CreateClient("testClient");
var responseMsg = await httpClient.GetAsync("WeatherForecast");
var result = await responseMsg.Content.ReadAsStringAsync();
Console.WriteLine(result);


app.MapGet("/", async () =>
{
    
    WeatherForecastService service = new WeatherForecastService(new HttpClient());
    var result = await service.GetWeatherForecastJsonAsync();
    return result;
});


app.Run();
